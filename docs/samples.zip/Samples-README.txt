The samples were obtained from the Total Reprint project.  They are screen
shots from the Apple II games Drol and Gumball, and from the Total Replay
collection.  https://archive.org/details/TotalReprint
